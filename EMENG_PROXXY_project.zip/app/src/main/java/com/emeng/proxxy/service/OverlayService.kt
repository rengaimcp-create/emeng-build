package com.emeng.proxxy.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.emeng.proxxy.MainActivity
import com.emeng.proxxy.manager.OverlayManager

class OverlayService : Service() {
    private var manager: OverlayManager? = null

    override fun onCreate() {
        super.onCreate()
        manager = OverlayManager(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            manager?.remove()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (manager?.hasPermission() != true) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        try {
            manager?.show {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        } catch (_: Exception) {
            manager?.remove()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "EMENG PROXXY Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 10, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = PendingIntent.getActivity(this, 11, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("EMENG PROXXY")
                .setContentText("Floating panel sedang berjalan")
                .setContentIntent(openIntent)
                .addAction(android.R.drawable.ic_media_pause, "Hentikan", stopPending)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("EMENG PROXXY")
                .setContentText("Floating panel sedang berjalan")
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        manager?.remove()
        manager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.emeng.proxxy.action.STOP_OVERLAY"
        private const val CHANNEL_ID = "emeng_overlay"
        private const val NOTIFICATION_ID = 4201
    }
}
