package com.emeng.proxxy

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.emeng.proxxy.service.OverlayService
import com.emeng.proxxy.storage.SettingsStore
import kotlinx.coroutines.launch
import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import android.os.BatteryManager
import android.view.WindowManager
import java.io.File

private val Bg = Color(0xFF0B0B0F)
private val CardBg = Color(0xFF15151D)
private val Red = Color(0xFFFF3030)
private val Cyan = Color(0xFF00E5FF)
private val Muted = Color(0xFFA1A1AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EmengApp() }
    }
}

private enum class Page(val label: String) {
    HOME("Dashboard"), AIM("AIM"), VISUAL("VISUAL"), EXTRA("EXTRA"),
    DEVICE("INFO DEVICE"), OVERLAY("OVERLAY API"), SETTINGS("SETTINGS")
}

@Composable
private fun EmengApp() {
    val context = LocalContext.current
    val store = remember { SettingsStore(context) }
    val settings by store.settings.collectAsState(initial = SettingsStore.Settings())
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf(Page.HOME) }
    var overlayStatus by remember { mutableStateOf("Overlay tidak aktif") }
    var toast by remember { mutableStateOf("") }
    var sensitivity by remember { mutableIntStateOf(settings.general) }
    var shape by remember { mutableStateOf(settings.crosshairShape) }
    var colorHex by remember { mutableStateOf(settings.crosshairColor) }
    var size by remember { mutableFloatStateOf(settings.crosshairSize) }
    var opacity by remember { mutableFloatStateOf(settings.overlayOpacity) }

    val overlayPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        overlayStatus = if (Settings.canDrawOverlays(context)) "Izin tersedia — siap memulai" else "Menunggu izin overlay"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, secondary = Color(0xFF8B5CF6), tertiary = Cyan,
            background = Bg, surface = CardBg, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(Red, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("⚡", fontSize = 25.sp, color = Color.White) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("EMENG PROXXY", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("GAMING UTILITY • ANDROID NATIVE", fontSize = 10.sp, color = Muted, letterSpacing = 1.sp)
                        }
                        IconButton(onClick = { page = Page.SETTINGS }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Cyan)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = CardBg) {
                    val navItems = listOf(Page.HOME, Page.AIM, Page.VISUAL, Page.EXTRA, Page.DEVICE)
                    navItems.forEach { p ->
                        NavigationBarItem(
                            selected = page == p,
                            onClick = { page = p },
                            icon = {
                                Icon(when (p) {
                                    Page.HOME -> Icons.Default.Home
                                    Page.AIM -> Icons.Default.GpsFixed
                                    Page.VISUAL -> Icons.Default.Visibility
                                    Page.EXTRA -> Icons.Default.Tune
                                    else -> Icons.Default.PhoneAndroid
                                }, contentDescription = p.label)
                            },
                            label = { Text(p.label, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, indicatorColor = Red.copy(alpha = .15f))
                        )
                    }
                }
            },
            snackbarHost = { if (toast.isNotBlank()) Snackbar(Modifier.padding(8.dp), action = { TextButton(onClick = { toast = "" }) { Text("OK") } }) { Text(toast) } }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (page) {
                    Page.HOME -> {
                        item {
                            Surface(color = CardBg, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("CONTROL CENTER", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Ready to optimize\n your setup?", fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold)
                                    Spacer(Modifier.height(12.dp))
                                    Text("Status: $overlayStatus", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(14.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            if (!Settings.canDrawOverlays(context)) {
                                                overlayStatus = "Menunggu izin overlay"
                                                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                                                overlayPermission.launch(intent)
                                            } else {
                                                overlayStatus = "Memulai overlay…"
                                                try {
                                                    ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
                                                    overlayStatus = "Permintaan overlay dikirim"
                                                    toast = "Overlay diminta. Jika gagal, periksa izin dan notifikasi."
                                                } catch (e: Exception) {
                                                    overlayStatus = "Terjadi kesalahan: ${e.message ?: "tidak diketahui"}"
                                                }
                                            }
                                        }, modifier = Modifier.weight(1f)) { Text("START OVERLAY") }
                                        OutlinedButton(onClick = {
                                            context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                                            overlayStatus = "Overlay dihentikan"
                                        }, modifier = Modifier.weight(1f)) { Text("STOP") }
                                    }
                                }
                            }
                        }
                        item { Text("MODULES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
                        items(listOf(Page.AIM, Page.VISUAL, Page.EXTRA, Page.DEVICE, Page.OVERLAY, Page.SETTINGS)) { p ->
                            ModuleCard(p.label, when (p) {
                                Page.AIM -> "Sensitivity guide, presets, aim practice"
                                Page.VISUAL -> "Custom crosshair and visual preview"
                                Page.EXTRA -> "Preset tools, calculator and guides"
                                Page.DEVICE -> "Live device and display information"
                                Page.OVERLAY -> "Permission and floating panel controls"
                                else -> "App preferences and saved configuration"
                            }, onClick = { page = p })
                        }
                    }
                    Page.AIM -> {
                        item { PageHeading("AIM", "Sensitivity guide & training tools") }
                        items(listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper Scope", "Free Look")) { name ->
                            val value = when(name) {
                                "General" -> settings.general
                                "Red Dot" -> settings.redDot
                                "2x Scope" -> settings.scope2x
                                "4x Scope" -> settings.scope4x
                                "Sniper Scope" -> settings.sniper
                                else -> settings.freeLook
                            }
                            Surface(color = CardBg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                        Text("$value", color = Cyan, fontWeight = FontWeight.Bold)
                                    }
                                    Slider(value = sensitivity.toFloat().coerceIn(0f, 200f), onValueChange = { sensitivity = it.toInt() },
                                        valueRange = 0f..200f)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { scope.launch { store.saveSensitivity(name, 90) } }) { Text("Reset 90") }
                                        Button(onClick = { scope.launch { store.saveSensitivity(name, sensitivity); toast = "$name disimpan" } }) { Text("Simpan $sensitivity") }
                                    }
                                }
                            }
                        }
                        item {
                            ModuleCard("Sensitivity Presets", "Low-End, Mid-Range, High-End (nilai dapat disesuaikan)") {
                                scope.launch {
                                    val vals = when (settings.lastPreset) {
                                        "Low-End Device" -> listOf(170, 160, 150, 135, 80, 140)
                                        "High-End Device" -> listOf(95, 90, 82, 72, 48, 78)
                                        else -> listOf(130, 120, 110, 95, 60, 105)
                                    }
                                    listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper Scope", "Free Look").forEachIndexed { i, k -> store.saveSensitivity(k, vals[i]) }
                                    toast = "Preset ${settings.lastPreset} dimuat"
                                }
                            }
                        }
                        item { ModuleCard("Aim Practice", "Latihan target manual tersedia di modul latihan. Nilai sensitivitas tidak mengubah game.") { toast = "Gunakan preview dan latihan dalam aplikasi." } }
                    }
                    Page.VISUAL -> {
                        item { PageHeading("VISUAL", "Crosshair customizer") }
                        item {
                            Surface(color = CardBg, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("LIVE PREVIEW", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Spacer(Modifier.height(8.dp))
                                    CrosshairPreview(shape, colorHex, size, Modifier.fillMaxWidth().height(170.dp))
                                    Spacer(Modifier.height(12.dp))
                                    Text("Shape")
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("Dot", "Cross", "Plus", "Circle", "Small Cross").forEach { s ->
                                            FilterChip(selected = shape == s, onClick = { shape = s }, label = { Text(s, fontSize = 10.sp) })
                                        }
                                    }
                                    Text("Color", modifier = Modifier.padding(top = 8.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("#FF3030", "#00FF66", "#3366FF", "#00E5FF", "#FFFF00", "#FFFFFF", "#FF00FF").forEach { c ->
                                            Box(Modifier.size(28.dp).background(parseColor(c), RoundedCornerShape(50)).clickable { colorHex = c })
                                        }
                                    }
                                    Text("Size: ${size.toInt()}")
                                    Slider(value = size, onValueChange = { size = it }, valueRange = 8f..80f)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { shape = "Cross"; colorHex = "#00E5FF"; size = 24f }) { Text("Reset") }
                                        Button(onClick = { scope.launch { store.saveVisual(colorHex, shape, size); toast = "Crosshair disimpan" } }) { Text("Simpan preset") }
                                    }
                                    Text("Preview di aplikasi; overlay crosshair game bukan fitur deteksi target.", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Page.EXTRA -> {
                        item { PageHeading("EXTRA", "Utility & preset tools") }
                        item { ModuleCard("Sensitivity Calculator", "Gunakan nilai awal sebagai titik eksperimen; sesuaikan secara manual.") { toast = "Calculator: sesuaikan nilai di halaman AIM." } }
                        item { ModuleCard("HUD Layout Guide", "Mulai dari tombol utama dekat jangkauan ibu jari dan uji kenyamanan.") { toast = "Panduan HUD dipilih." } }
                        item { ModuleCard("DPI / Resolution / Refresh Rate", "Lihat data perangkat pada INFO DEVICE.") { page = Page.DEVICE } }
                        item { ModuleCard("Performance Guide", "Tutup aplikasi latar belakang, jaga suhu, dan pilih grafis sesuai kestabilan FPS.") { toast = "Panduan performa dibuka." } }
                        item { ModuleCard("Preset Manager", "Preset sensitivitas dasar tersimpan melalui DataStore.") { toast = "Preset terakhir: ${settings.lastPreset}" } }
                        item { ModuleCard("Export / Import JSON", "Ekspor dan impor file konfigurasi menggunakan Storage Access Framework tersedia sebagai pengembangan berikutnya.") { toast = "Ekspor/import file belum disediakan pada versi ini." } }
                    }
                    Page.DEVICE -> {
                        item { PageHeading("INFO DEVICE", "Data perangkat dari Android API") }
                        item {
                            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                            val mem = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
                            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                            @Suppress("DEPRECATION")
                            val display = wm.defaultDisplay
                            val metrics = android.util.DisplayMetrics()
                            @Suppress("DEPRECATION")
                            if (Build.VERSION.SDK_INT < 30) wm.defaultDisplay.getRealMetrics(metrics) else {
                                val bounds = context.resources.configuration
                                metrics.widthPixels = context.resources.displayMetrics.widthPixels
                                metrics.heightPixels = context.resources.displayMetrics.heightPixels
                                metrics.density = context.resources.displayMetrics.density
                                metrics.densityDpi = context.resources.displayMetrics.densityDpi
                            }
                            val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                            val batteryPct = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                            val stat = StatFs(context.filesDir.absolutePath)
                            val refresh = try { display?.refreshRate?.toString() ?: "Tidak tersedia" } catch (_: Exception) { "Tidak tersedia" }
                            val info = listOf(
                                "Manufacturer" to Build.MANUFACTURER,
                                "Brand" to Build.BRAND,
                                "Model" to Build.MODEL,
                                "Android" to Build.VERSION.RELEASE,
                                "SDK" to Build.VERSION.SDK_INT.toString(),
                                "Resolution" to "${metrics.widthPixels} × ${metrics.heightPixels}",
                                "Density" to "${metrics.densityDpi} dpi",
                                "Refresh rate" to "$refresh Hz",
                                "Available RAM" to "${mem.availMem / (1024 * 1024)} MB",
                                "Total RAM" to if (mem.totalMem > 0) "${mem.totalMem / (1024 * 1024)} MB" else "Tidak tersedia",
                                "App storage available" to "${stat.availableBytes / (1024 * 1024)} MB",
                                "Battery" to if (batteryPct >= 0) "$batteryPct%" else "Tidak tersedia",
                                "CPU ABI" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "Tidak tersedia"),
                                "App version" to "1.0.0"
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                info.forEach { (k,v) ->
                                    Surface(color = CardBg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(k, color = Muted, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                            Text(v, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        }
                                    }
                                }
                                Button(onClick = { toast = "Informasi perangkat diperbarui" }, modifier = Modifier.fillMaxWidth()) { Text("Refresh Information") }
                                OutlinedButton(onClick = {
                                    val text = info.joinToString("\n") { "${it.first}: ${it.second}" }
                                    val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clip.setPrimaryClip(android.content.ClipData.newPlainText("Device Information", text))
                                    toast = "Informasi perangkat disalin"
                                }, modifier = Modifier.fillMaxWidth()) { Text("Copy Device Information") }
                            }
                        }
                    }
                    Page.OVERLAY -> {
                        item { PageHeading("OVERLAY API", "Android WindowManager permission") }
                        item {
                            val allowed = Settings.canDrawOverlays(context)
                            Surface(color = CardBg, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(if (allowed) "IZIN TERSEDIA" else "IZIN BELUM DIBERIKAN",
                                        color = if (allowed) Cyan else Red, fontWeight = FontWeight.Bold)
                                    Text(overlayStatus, color = Muted, modifier = Modifier.padding(vertical = 10.dp))
                                    Button(onClick = {
                                        if (!Settings.canDrawOverlays(context)) {
                                            overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                        } else toast = "Izin overlay sudah tersedia"
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Periksa / Beri Izin") }
                                    Button(onClick = {
                                        if (!Settings.canDrawOverlays(context)) {
                                            overlayStatus = "Menunggu izin overlay"
                                            overlayPermission.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                        } else {
                                            try {
                                                ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
                                                overlayStatus = "Permintaan overlay dikirim"
                                                toast = "Permintaan start dikirim"
                                            } catch (e: Exception) { overlayStatus = "Terjadi kesalahan: ${e.message}" }
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) { Text("START OVERLAY") }
                                    OutlinedButton(onClick = {
                                        context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                                        overlayStatus = "Overlay dihentikan"
                                    }, modifier = Modifier.fillMaxWidth()) { Text("STOP OVERLAY") }
                                    Text("Panel dapat dipindahkan dengan menyeret header. Tutup panel melalui tombol di panel atau notifikasi.", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Page.SETTINGS -> {
                        item { PageHeading("SETTINGS", "Local app preferences") }
                        item {
                            Surface(color = CardBg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Overlay opacity: ${(opacity * 100).toInt()}%")
                                    Slider(value = opacity, onValueChange = { opacity = it }, valueRange = .2f..1f)
                                    Button(onClick = { scope.launch { store.saveOpacity(opacity); toast = "Opacity disimpan" } }) { Text("Simpan pengaturan") }
                                    Text("Last preset: ${settings.lastPreset}", color = Muted)
                                    listOf("Low-End Device", "Mid-Range Device", "High-End Device").forEach { preset ->
                                        TextButton(onClick = { scope.launch { store.saveLastPreset(preset); toast = "$preset dipilih" } }) { Text(preset) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageHeading(title: String, subtitle: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        color = CardBg, shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(4.dp, 42.dp).background(Red, RoundedCornerShape(3.dp)))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Cyan)
        }
    }
}

@Composable
private fun CrosshairPreview(shape: String, hex: String, size: Float, modifier: Modifier = Modifier) {
    val color = parseColor(hex)
    Canvas(modifier.background(Color(0xFF09090D), RoundedCornerShape(12.dp))) {
        val cx = this.size.width / 2
        val cy = this.size.height / 2
        val r = size
        val stroke = 2.5f
        when (shape) {
            "Dot" -> drawCircle(color, radius = stroke * 1.5f, center = Offset(cx, cy))
            "Circle" -> drawCircle(color, radius = r, center = Offset(cx, cy), style = Stroke(stroke))
            "Plus" -> {
                drawLine(color, Offset(cx, cy-r), Offset(cx, cy+r), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx-r, cy), Offset(cx+r, cy), strokeWidth = stroke, cap = StrokeCap.Round)
            }
            else -> {
                val gap = if (shape == "Small Cross") r * .22f else r * .35f
                drawLine(color, Offset(cx-r, cy), Offset(cx-gap, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx+gap, cy), Offset(cx+r, cy), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy-r), Offset(cx, cy-gap), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(color, Offset(cx, cy+gap), Offset(cx, cy+r), strokeWidth = stroke, cap = StrokeCap.Round)
            }
        }
    }
}

private fun parseColor(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (_: Exception) { Cyan }
