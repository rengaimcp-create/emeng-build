package com.emeng.proxxy.manager

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayManager(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null

    fun hasPermission(): Boolean = Settings.canDrawOverlays(context)
    fun isShowing(): Boolean = panel != null

    @Throws(SecurityException::class, WindowManager.BadTokenException::class)
    fun show(onClose: () -> Unit) {
        if (!hasPermission()) throw SecurityException("Izin tampil di atas aplikasi lain belum diberikan.")
        if (panel != null) return

        val density = context.resources.displayMetrics.density
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * density).toInt(), (12 * density).toInt(), (14 * density).toInt(), (12 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.rgb(21, 21, 29))
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(255, 48, 48))
            }
        }
        val header = TextView(context).apply {
            text = "⚡ EMENG PROXXY  •  ACTIVE"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        root.addView(header)
        val info = TextView(context).apply {
            text = "Floating utility panel\nAIM  •  VISUAL  •  EXTRA  •  AOI"
            setTextColor(Color.rgb(0, 229, 255))
            textSize = 12f
        }
        root.addView(info)
        val close = Button(context).apply {
            text = "STOP / CLOSE"
            setOnClickListener { remove(); onClose() }
        }
        root.addView(close)

        val lp = WindowManager.LayoutParams(
            (260 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (120 * density).toInt()
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (_: Exception) { remove() }
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
        panel = root
        params = lp
    }

    fun updateOpacity(opacity: Float) {
        panel?.alpha = opacity.coerceIn(0.2f, 1f)
    }

    fun remove() {
        val old = panel ?: return
        try { wm.removeView(old) } catch (_: IllegalArgumentException) { }
        panel = null
        params = null
    }
}
