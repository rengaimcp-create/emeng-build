package com.emeng.proxxy.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "emeng_settings")

class SettingsStore(private val context: Context) {
    private val general = intPreferencesKey("sensitivity_general")
    private val redDot = intPreferencesKey("sensitivity_red_dot")
    private val scope2x = intPreferencesKey("sensitivity_2x")
    private val scope4x = intPreferencesKey("sensitivity_4x")
    private val sniper = intPreferencesKey("sensitivity_sniper")
    private val freeLook = intPreferencesKey("sensitivity_free_look")
    private val crosshairColor = stringPreferencesKey("crosshair_color")
    private val crosshairShape = stringPreferencesKey("crosshair_shape")
    private val crosshairSize = floatPreferencesKey("crosshair_size")
    private val overlayOpacity = floatPreferencesKey("overlay_opacity")
    private val lastPreset = stringPreferencesKey("last_preset")

    data class Settings(
        val general: Int = 90,
        val redDot: Int = 85,
        val scope2x: Int = 80,
        val scope4x: Int = 70,
        val sniper: Int = 45,
        val freeLook: Int = 75,
        val crosshairColor: String = "#00E5FF",
        val crosshairShape: String = "Cross",
        val crosshairSize: Float = 24f,
        val overlayOpacity: Float = 0.92f,
        val lastPreset: String = "Mid-Range Device"
    )

    val settings = context.dataStore.data.map { p ->
        Settings(
            general = p[general] ?: 90,
            redDot = p[redDot] ?: 85,
            scope2x = p[scope2x] ?: 80,
            scope4x = p[scope4x] ?: 70,
            sniper = p[sniper] ?: 45,
            freeLook = p[freeLook] ?: 75,
            crosshairColor = p[crosshairColor] ?: "#00E5FF",
            crosshairShape = p[crosshairShape] ?: "Cross",
            crosshairSize = p[crosshairSize] ?: 24f,
            overlayOpacity = p[overlayOpacity] ?: 0.92f,
            lastPreset = p[lastPreset] ?: "Mid-Range Device"
        )
    }

    suspend fun saveSensitivity(key: String, value: Int) {
        val target = when (key) {
            "General" -> general
            "Red Dot" -> redDot
            "2x Scope" -> scope2x
            "4x Scope" -> scope4x
            "Sniper Scope" -> sniper
            else -> freeLook
        }
        context.dataStore.edit { it[target] = value.coerceIn(0, 200) }
    }

    suspend fun saveVisual(color: String, shape: String, size: Float) {
        context.dataStore.edit {
            it[crosshairColor] = color
            it[crosshairShape] = shape
            it[crosshairSize] = size.coerceIn(8f, 80f)
        }
    }

    suspend fun saveOpacity(value: Float) {
        context.dataStore.edit { it[overlayOpacity] = value.coerceIn(0.2f, 1f) }
    }

    suspend fun saveLastPreset(value: String) {
        context.dataStore.edit { it[lastPreset] = value.take(80) }
    }
}
