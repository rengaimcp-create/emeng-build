# EMENG PROXXY

Proyek Android native Kotlin + Jetpack Compose, minimum Android 8.0 (API 26).

## Yang tersedia dalam proyek ini
- Dashboard dan navigasi halaman.
- UI AIM dengan pengaturan sensitivitas lokal dan preset awal.
- Visual crosshair customizer dengan preview langsung.
- Informasi perangkat memakai API Android.
- Overlay panel native berbasis WindowManager dan izin `SYSTEM_ALERT_WINDOW`.
- Foreground service dengan notifikasi dan tindakan berhenti.
- Penyimpanan pengaturan memakai Preferences DataStore.
- Halaman Extra/Settings dengan status keterbatasan fitur yang belum tersedia.

## Membuka dan build
1. Buka folder proyek ini di Android Studio versi yang mendukung AGP 8.7.3.
2. Gunakan JDK 17.
3. Sinkronkan Gradle dan tunggu dependensi selesai.
4. Jalankan di perangkat Android atau emulator API 26+.
5. Untuk APK debug: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. File biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

CLI (dari root proyek):
```bash
./gradlew assembleDebug
```

Release APK:
```bash
./gradlew assembleRelease
```
Untuk distribusi, konfigurasi signing key sendiri di Android Studio atau konfigurasi signing Gradle yang aman. Jangan menyimpan kredensial signing ke repository.

## Izin overlay
Buka OVERLAY API atau tekan START OVERLAY. Aplikasi akan membuka pengaturan Android jika izin belum diberikan. Setelah izin diberikan, tekan START OVERLAY lagi. Overlay dapat dipindahkan melalui header, ditutup lewat tombol panel, atau dihentikan dari notifikasi.

## Catatan status
Proyek ini belum dikompilasi atau diuji pada perangkat fisik dalam lingkungan pembuatan artefak ini. Overlay Android 14/15 dan kebijakan foreground service dapat berbeda menurut perangkat/OEM; verifikasi melalui Android Studio dan perangkat target sebelum rilis.

Fitur ekspor/impor JSON, latihan reaksi lengkap, penyuntingan preset multi-entri, AOI overlay terpisah, ukuran panel yang dapat diubah, dan ekspor laporan perangkat belum diimplementasikan pada versi ini; UI menyatakan keterbatasan tersebut dan tidak mengklaim selesai. Tidak ada interaksi dengan memori/proses game.
